export const fetchAnalysis = async (url) => {
    // Mock response for demonstration
    return {
        polarity: 'positive',
        subjectivity: 'subjective',
        text: 'This is a sample text snippet from the article.'
    };
}
